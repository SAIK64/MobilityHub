---
name: Forest Academic Mobility
colors:
  surface: '#f6fbed'
  surface-dim: '#d7dcce'
  surface-bright: '#f6fbed'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f5e7'
  surface-container: '#ebf0e2'
  surface-container-high: '#e5eadc'
  surface-container-highest: '#dfe4d7'
  on-surface: '#181d15'
  on-surface-variant: '#44483f'
  inverse-surface: '#2d3229'
  inverse-on-surface: '#eef3e5'
  outline: '#74796e'
  outline-variant: '#c4c8bc'
  surface-tint: '#4d653e'
  primary: '#1d3312'
  on-primary: '#ffffff'
  primary-container: '#334a26'
  on-primary-container: '#9eb98b'
  inverse-primary: '#b3cf9f'
  secondary: '#456734'
  on-secondary: '#ffffff'
  secondary-container: '#c6eead'
  on-secondary-container: '#4b6d39'
  tertiary: '#283027'
  on-tertiary: '#ffffff'
  tertiary-container: '#3e463d'
  on-tertiary-container: '#abb3a8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cfebba'
  primary-fixed-dim: '#b3cf9f'
  on-primary-fixed: '#0b2003'
  on-primary-fixed-variant: '#364d29'
  secondary-fixed: '#c6eead'
  secondary-fixed-dim: '#abd293'
  on-secondary-fixed: '#072100'
  on-secondary-fixed-variant: '#2e4f1e'
  tertiary-fixed: '#dde5d8'
  tertiary-fixed-dim: '#c1c9bd'
  on-tertiary-fixed: '#161d16'
  on-tertiary-fixed-variant: '#414940'
  background: '#f6fbed'
  on-background: '#181d15'
  surface-variant: '#dfe4d7'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.025em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-tablet: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

